package com.smartsched.model;



public class AllModule {
    
    private String moduleId;
    private String title;
    private String description;

    // Getters and Setters
    public String getModuleId() { return moduleId; }
    public void setModuleId(String moduleId) { this.moduleId = moduleId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
